char toLower(char c) {
	if ((c >= 'A') && (c <= 'Z'))
		c += 32;
	return (c);
}
