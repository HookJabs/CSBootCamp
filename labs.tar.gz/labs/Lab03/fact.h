long int factorial(int); //Prototype
